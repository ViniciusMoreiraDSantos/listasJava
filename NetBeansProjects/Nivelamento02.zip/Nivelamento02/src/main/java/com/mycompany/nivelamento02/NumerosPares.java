/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nivelamento02;

/**
 *
 * @author t-gamer
 */
public class NumerosPares {
    public static void main(String[] args) {
       Integer i = 0;
       
        while (i < 41) {            
            i++;
            if (i %2 == 0) {
                System.out.println(i);
            }
            
        }
    }
}
